Epilepsyside.exe
There is 20 GDI Effects With 3D GDI
Run It On Windows 7 - 11
If You Want To Test It Please Run The Safe Version
Dont Run The Destructive Version Because It Can Cause Data Loss 

-------------------------------------
Malware By RikGDI

https//www.youtube.com/@rikgdi
https//www.github.com/rikgdi
--------------------------------------